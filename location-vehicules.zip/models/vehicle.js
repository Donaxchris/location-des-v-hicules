const db = require('../database');

const Vehicle = {
  create: (name, brand, callback) => {
    const query = 'INSERT INTO vehicles (name, brand) VALUES (?, ?)';
    db.run(query, [name, brand], function (err) {
      callback(err, { id: this.lastID, name, brand, available: 1 });
    });
  },

  getAllAvailable: (callback) => {
    db.all('SELECT * FROM vehicles WHERE available = 1', [], callback);
  },

  searchByName: (name, callback) => {
    db.all('SELECT * FROM vehicles WHERE name LIKE ?', [`%${name}%`], callback);
  },

  searchByBrand: (brand, callback) => {
    db.all('SELECT * FROM vehicles WHERE brand LIKE ?', [`%${brand}%`], callback);
  },
};

module.exports = Vehicle;
