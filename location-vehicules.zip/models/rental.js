const db = require('../database');

const Rental = {
  rent: (vehicleId, clientId, callback) => {
    const now = new Date().toISOString();
    db.run(\`
      INSERT INTO rentals (vehicle_id, client_id, date_rented)
      VALUES (?, ?, ?)\`, [vehicleId, clientId, now], function (err) {
        if (err) return callback(err);
        db.run('UPDATE vehicles SET available = 0 WHERE id = ?', [vehicleId], () => {
          callback(null, { rentalId: this.lastID, vehicleId, clientId, date_rented: now });
        });
    });
  },

  returnVehicle: (vehicleId, callback) => {
    const now = new Date().toISOString();
    db.run(\`
      UPDATE rentals
      SET date_returned = ?
      WHERE vehicle_id = ? AND date_returned IS NULL
    \`, [now, vehicleId], function (err) {
      if (err) return callback(err);
      db.run('UPDATE vehicles SET available = 1 WHERE id = ?', [vehicleId], () => {
        callback(null, { message: 'Véhicule retourné avec succès.' });
      });
    });
  },

  getClientsByVehicle: (vehicleId, callback) => {
    db.all(\`
      SELECT c.* FROM clients c
      JOIN rentals r ON c.id = r.client_id
      WHERE r.vehicle_id = ?
    \`, [vehicleId], callback);
  },

  getVehiclesByClient: (clientId, callback) => {
    db.all(\`
      SELECT v.* FROM vehicles v
      JOIN rentals r ON v.id = r.vehicle_id
      WHERE r.client_id = ?
    \`, [clientId], callback);
  }
};

module.exports = Rental;
