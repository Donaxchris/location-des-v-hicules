const db = require('../database');

const Client = {
  create: (name, email, callback) => {
    const query = 'INSERT INTO clients (name, email) VALUES (?, ?)';
    db.run(query, [name, email], function (err) {
      callback(err, { id: this.lastID, name, email });
    });
  },

  getAll: (callback) => {
    db.all('SELECT * FROM clients', [], callback);
  },

  searchByName: (name, callback) => {
    db.all('SELECT * FROM clients WHERE name LIKE ?', [`%${name}%`], callback);
  },
};

module.exports = Client;
