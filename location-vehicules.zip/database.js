const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./location.db');

db.serialize(() => {
  db.run(\`
    CREATE TABLE IF NOT EXISTS vehicles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      brand TEXT NOT NULL,
      available INTEGER DEFAULT 1
    )\`);
  db.run(\`
    CREATE TABLE IF NOT EXISTS clients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE
    )\`);
  db.run(\`
    CREATE TABLE IF NOT EXISTS rentals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vehicle_id INTEGER,
      client_id INTEGER,
      date_rented TEXT,
      date_returned TEXT,
      FOREIGN KEY(vehicle_id) REFERENCES vehicles(id),
      FOREIGN KEY(client_id) REFERENCES clients(id)
    )\`);
});

module.exports = db;
