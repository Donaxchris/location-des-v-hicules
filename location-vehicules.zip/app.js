const express = require('express');
const bodyParser = require('body-parser');
const vehicleRoutes = require('./routes/vehicles');
const clientRoutes = require('./routes/clients');
const rentalRoutes = require('./routes/rentals');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

app.use('/vehicles', vehicleRoutes);
app.use('/clients', clientRoutes);
app.use('/rentals', rentalRoutes);

app.get('/', (req, res) => res.send('🚗 Location véhicules - API opérationnelle'));

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
