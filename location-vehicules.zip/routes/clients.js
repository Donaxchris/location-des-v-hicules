const express = require('express');
const router = express.Router();
const Client = require('../models/client');

router.post('/', (req, res) => {
  const { name, email } = req.body;
  Client.create(name, email, (err, client) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json(client);
  });
});

router.get('/', (req, res) => {
  Client.getAll((err, clients) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(clients);
  });
});

router.get('/search', (req, res) => {
  const { name } = req.query;
  if (!name) return res.status(400).json({ error: 'Nom requis' });

  Client.searchByName(name, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

module.exports = router;
