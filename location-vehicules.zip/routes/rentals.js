const express = require('express');
const router = express.Router();
const Rental = require('../models/rental');

router.post('/', (req, res) => {
  const { vehicleId, clientId } = req.body;
  Rental.rent(vehicleId, clientId, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json(result);
  });
});

router.post('/return', (req, res) => {
  const { vehicleId } = req.body;
  Rental.returnVehicle(vehicleId, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(result);
  });
});

router.get('/vehicle/:vehicleId', (req, res) => {
  Rental.getClientsByVehicle(req.params.vehicleId, (err, clients) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(clients);
  });
});

router.get('/client/:clientId', (req, res) => {
  Rental.getVehiclesByClient(req.params.clientId, (err, vehicles) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(vehicles);
  });
});

module.exports = router;
