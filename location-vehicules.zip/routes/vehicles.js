const express = require('express');
const router = express.Router();
const Vehicle = require('../models/vehicle');

router.post('/', (req, res) => {
  const { name, brand } = req.body;
  Vehicle.create(name, brand, (err, vehicle) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json(vehicle);
  });
});

router.get('/', (req, res) => {
  Vehicle.getAllAvailable((err, vehicles) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(vehicles);
  });
});

router.get('/search', (req, res) => {
  const { name, brand } = req.query;
  if (name) {
    Vehicle.searchByName(name, (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(results);
    });
  } else if (brand) {
    Vehicle.searchByBrand(brand, (err, results) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(results);
    });
  } else {
    res.status(400).json({ message: 'Veuillez fournir un nom ou une marque.' });
  }
});

module.exports = router;
